document.getElementById('analyzeButton').addEventListener('click', analyzeImage);

function analyzeImage() {
    const input = document.getElementById('imageInput').files[0];
    if (!input) {
        alert('Please select an image first.');
        return;
    }

    const reader = new FileReader();
    reader.onloadend = () => {
        const base64data = reader.result.split(',')[1];
        callVisionAPI(base64data);
    };
    reader.readAsDataURL(input);
}

function callVisionAPI(imageData) {
    const subscriptionKey = '545b3f3993a343de8a17cb7b4e70e95a';
    const endpoint = 'https://testvisionpv.cognitiveservices.azure.com/';

    fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/octet-stream',
            'Ocp-Apim-Subscription-Key': subscriptionKey
        },
        body: convertBase64ToBlob(imageData)
    })
    .then(response => response.json())
    .then(data => {
        document.getElementById('result').textContent = JSON.stringify(data, null, 2);
    })
    .catch(error => console.error('Error:', error));
}

function convertBase64ToBlob(base64) {
    const byteCharacters = atob(base64);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    return new Blob([byteArray], { type: 'application/octet-stream' });
}